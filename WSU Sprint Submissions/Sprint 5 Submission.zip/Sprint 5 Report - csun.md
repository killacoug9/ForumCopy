# Sprint 5 Report (2/2/24 - 3/2/2023)

## What's New (User Facing)
 * A 'My Representatives' page
 * A 'My Elections' page
 * Search bar for those 2 pages
 * Corresponding output will be performed based on the address entered by the user for 'My Representatives'
 * Corresponding output will be performed based on the address entered by the user for 'My Elections'
 * Elections administrators' information table will display in 'My Elections' page
 * Corresponding elections administrators' information will be high-light based on the zip code entered by the user for 'My Elections' page
 * You can visit website for more information: https://www.american.forum/

## Work Summary (Developer Facing)
In this sprint, we mainly conduct research and development on ‘My Representatives’ and ‘My Elections’ pages. We try to figure out how to get and show all representative information and elections in Texas, and we use an API to do this. We created a search bar through which users can query addresses and zip codes. Then you will get the corresponding output from google civic information api and elections administrators information.

## Unfinished Work
We finished most of the work for this sprint, but there are some bugs and display errors need to fix.
 
## Incomplete Issues/User Stories
There are still some bugs for API applications, since this is a new thing for us, we spent a lots time to figure out how to do it.

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
My Representatives:
https://github.com/capturedsun/Forum/blob/main/Web/myRepresentatives/MyRepresentatives.js
https://github.com/capturedsun/Forum/blob/main/Web/myRepresentatives/congressApi.js
My Elections:
https://github.com/capturedsun/Forum/blob/main/Web/myElections/myElections.js
 
## Retrospective Summary
Here's what went well:
   * Successful created 'My Representatives' page
   * Successful created 'My Elections' page
   * Successful applied API
   * Get the corresponding output from google civic information api
 
Here's what we'd like to improve:
   * Keep working on api, fix those bugs
   * Formatting the output
  
Here are changes we plan to implement in the next sprint:
   * Enhancing the election data or building out the iOS app or giving  people polling data