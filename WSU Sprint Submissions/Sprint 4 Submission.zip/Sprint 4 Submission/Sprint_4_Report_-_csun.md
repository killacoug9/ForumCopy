# Sprint 4  Report (12/5/2023 - 2/2/2024)

## What's New (User Facing)
 * Made a link that can open on iphone to test the forum app.
 * https://testflight.apple.com/join/LD9svki2 (we have an apple app!)
 * Added push notification support for the iOS app
 * White bar on top and bottom of the app has been removed on iOS

## Work Summary (Developer Facing)
This sprint was the first sprint for this semester. We are trying to improve the content of Forum app. Based on the original content, we plan to add Budget Page and Elections. We found some resources about Budget to provide reference. Our client wants us to focus primarily on the upcoming Texas elections on March 5th and displaying that information on the page.

## Unfinished Work
* We are still trying to figure out how to get and show all elections in texas
* We are still improving the ios interface
* The budget page and texas elections page
* Developing the democratic primaries page

## Completed Issues/User Stories
We didn't feel there were any stories worth sharing. No new issues were fixed.

## Incomplete Issues/User Stories
The developer version of the iOS app is unstable due to the implementation of the Tab Bar UI element. Both the team and the client believe that this issue has something to do with the way SwiftUI handles its content views.

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * [Home.swift](https://github.com/capturedsun/Forum/blob/main/Shared/Home.swift)
 * [LocationManager.swift](https://github.com/capturedsun/Forum/blob/main/Shared/LocationManager.swift)
 * [AppDelegate.swift] (https://github.com/capturedsun/Forum/blob/main/Shared/API/AppDelegate.swift)

## Retrospective Summary
Here's what went well:
  * iOS development going much better than expected
  * Webpage got cleaned up

Here are changes we plan to implement in the next sprint:
   * Implementing an API for displaying executive orders
   * Implement more pages. Starting with the democratic primaries page
   * Clean-up and add to the republican primaries page
   * Implement Budget Page
   * Implement Texas Elections Page
