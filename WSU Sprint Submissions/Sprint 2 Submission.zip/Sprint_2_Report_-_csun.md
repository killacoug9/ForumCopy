# Sprint 2 Report (10/5/23 - 11/5/2023)

## What's New (User Facing)
 * Changed the navbar to be blurry
 * Moved the Forum Logo
 * Changed how candidates/presidents are displayed again (bigger picture, with border and shadow now)
 * Added animation to hovering/clicking on the candidate/president displays
 * Added "President of the United States" Seal to the bottom portion of the screen

## Work Summary (Developer Facing)
This sprint was the second sprint of the project. Our team has been focusing on the display-side of the website. Now that we've been working on the project for a good number of weeks a defined style is really starting to show on our website. The over-all product is starting to come together and we're all excited to see the final result.

## Unfinished Work
We were able to complete our tasks for the given sprint.
 
 ## Incomplete Issues/User Stories
 We completed our tasks for the given sprint

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * [NavBar.js](https://github.com/capturedsun/Forum/blob/main/Web/NavBar.js)
 * [President.js](https://github.com/capturedsun/Forum/blob/main/Web/President.js)
 * [RepublicanPrimaries.js](https://github.com/capturedsun/Forum/blob/main/Web/RepublicanPrimaries.js)
 
## Retrospective Summary
Here's what went well:
 * Navbar and Forum logo successfully improved upon
 * Candidates/President image changes (border, animation, shadow)
 * Presidential Seal Successfully added

Here's what we'd like to improve:
   * Certain animations currently move through the navbar, looks unprofessional
  
Here are changes we plan to implement in the next sprint:
   * Implement Republican primaries page