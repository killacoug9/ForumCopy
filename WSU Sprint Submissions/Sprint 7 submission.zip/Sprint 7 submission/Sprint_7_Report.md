# Sprint 7 Report (4/2/2024 - 5/2/2024)

## What's New (User Facing)
 * No new features

## Work Summary (Developer Facing)
Unfortunately, for our final sprint we opted to add no new features. We were able to update the document with some last touches but the actual project was left as-is due to it being in a good state. Our client did not wish for us to add too many more features so we opted to leave the project as is.

## Retrospective Summary
Here's what went well this semester:
  * Effective collaboration across the two teams working on the project
  * Successful integration of the Twitter Clone UI
  * Good progress on the website
