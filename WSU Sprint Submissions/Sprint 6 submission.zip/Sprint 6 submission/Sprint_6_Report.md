# Sprint 6 Report (3/2/2024 - 4/2/2024)

## What's New (User Facing)
 * Added Twitter Clone UI
 * Updates to certain representatives due to them changing political parties
 * Added link to presidential polls

## Work Summary (Developer Facing)
This sprint, our team worked on implementing several user-facing features enriching the app's content and enhances user experience. A highlight was the addition of the Twitter Clone UI, which required SwiftUI components to integrate it into the project. We also updated our representatives' database in response to recent political party changes, ensuring our content remains current. Furhtermore, we incorporated a dirct link to presidential polls, catering to our politcally engaged user base.

## Unfinished Work
One of the tasks we couldn't complete was related to the app's navigation UI. We aimed to implement new navigation features such as the Tab Bar and swiping functionality, but decided against it as the LocationManager.swift file caused issues with app stability as pulling the user's location somehow led to crashes when interacting with various UI elements within the app.
 
 ## Incomplete Issues/User Stories
 Here are links to issues we worked on but did not complete in this sprint:
 
 * https://github.com/capturedsun/Forum/blob/main/Shared/LocationManager.swift <<We decided to scrap navigation UI this sprint as pulling the location may have lead to crashes in separate UI views.>>
 
## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * [President.js](https://github.com/capturedsun/Forum/blob/main/Web/President/President.js)
 * [TwitterCloneView.swift](https://github.com/capturedsun/Forum/blob/main/Shared/Twitter%20Clone/TwitterCloneView.swift)
 * [Home.swift](https://github.com/capturedsun/Forum/blob/main/Shared/Home.swift)
 
## Retrospective Summary
Here's what went well:
  * Effective collaboration across the two teams working on the project
  * Successful integration of the Twitter Clone UI
 
Here's what we'd like to improve:
   * Keep working on api, fix those bugs
   * Formatting the output
  
Here are changes we plan to implement in the next sprint:
   * Continue enhancing the election data or building out the iOS app or giving  people polling data