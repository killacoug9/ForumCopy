# Sprint 1 Report (8/15/23 - 10/5/2023)

## What's New (User Facing)
 * Made working link for the program: https://www.american.forum/
 * Inputted the different candidates for the upcoming presidential race
 * Created navbar at the top that plays an animation when scrolling down the page
 * Added wikipedia links to each of the different candidates
 * Organizated the candidates by party affiliation

## Work Summary (Developer Facing)
This sprint was the first sprint for the entire project. We started the website from scratch. Our client is kind enough to divide our tasks into trello boards so we've been following those to complete our tasks. To go about doing this work our team has divided up who does what tasks from the trello board. The biggest barrier we needed to overcome was within the first week and that was communication. Once we got in-contact with our client we agreed upon weekly meetings to confirm our progress on the project.

## Unfinished Work
We were able to complete our tasks for the given sprint.
 
 ## Incomplete Issues/User Stories
 We completed our tasks for the given sprint

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * [NavBar.js](https://github.com/capturedsun/Forum/blob/main/Web/NavBar.js)
 * [President.js](https://github.com/capturedsun/Forum/blob/main/Web/President.js)
 * [RepublicanPrimaries.js](https://github.com/capturedsun/Forum/blob/main/Web/RepublicanPrimaries.js)
 
## Retrospective Summary
Here's what went well:
  * Successful inclusion of all candidates on the page
  * Successful creation of a site navbar as well as the animations attached to it
  * Implementation of a trello board
  * Designated consistent meetings for our team
 
Here's what we'd like to improve:
   * Navbar animation currently doesn't put a shadow under the eagle logo (this is very low priority)
  
Here are changes we plan to implement in the next sprint:
   * Make photo links for candidates not take up any white space
   * Implement Republican primaries page