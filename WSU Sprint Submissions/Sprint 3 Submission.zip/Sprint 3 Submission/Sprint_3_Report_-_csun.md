# Sprint x Report  (11/5/2023 -  12/5/2023)

## What's New (User Facing)
 * Implemented a republican primaries page
 * Implemented a system for displaying runners for primaries in a graphic based off of polls, 
 larger portraits in this graphic have more expected votes
 * Worked on a system to add new website pages with our client, this feature wasn't available before (we only had one page)
 * Cleaned up our code and updated the file storage system to compliment the new webpages (reorganized a lot)
 * Added a navigation banner that currently isn't being used but we're planning to implement in some way in the future.
 * Implemented a basic node server for mobile
 * Updated our navbar and presidentpage code with new logic

## Work Summary (Developer Facing)
This sprint was the third sprint of the project. Our team has been focusing on buffing out the site's interface and styling as well as creating a few new pages and developing a way to implement mobile user notifications. The project has been going quite well as several new features have been implemented to freshen up the site to make it more presentable. We are focused on ensuring our data is as easy to read as possible while maintaining a modern look and feel.

## Unfinished Work
* We ran into difficulties implementing push notifications due to issues regarding getting certain authentications and certificates from Sam's Apple developer account 
* Haven't decided whether or not to implement a node server or just use Apple's CloudKit API as each have their own pros and cons to consider
* The z-index of some of our items are off. Currently the display for some items is incorrect because of this layering issue

## Completed Issues/User Stories
* User story (Niko): the republican primay page took a lot of time and was quite the learning curve.
Having the different runners display around the center runner (the current highest voted runner) proved quite difficult.
The final result looks quite nice though, you have the largest image in the center with all of the smaller images hover/orbit
around the center
 
 ## Incomplete Issues/User Stories
We had no incomplete issues

## Code Files for Review
Please review the following code files, which were actively developed during this sprint, for quality:
 * [server.js](https://github.com/capturedsun/Forum/blob/main/server.js)
 * [RepublicanPrimaries.js](https://github.com/capturedsun/Forum/blob/main/Web/President/RepublicanPrimaries.js)
 * [Name of code file 3](https://github.com/your_repo/file_extension)
 
## Retrospective Summary
Here's what went well:
  * Republican Primaries page has been created
  * Made sure UI elements did not interfere with the page itself


Here are changes we plan to implement in the next sprint:
   * Implementing an API for displaying executive orders
   * Push notifications on IOS
   * Remove white bar from top and bottom of app version
   * Implement more pages. Starting with the democratic primaries page
   * Clean-up and add to the republican primaries page